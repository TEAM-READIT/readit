-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: readit
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community`
--

DROP TABLE IF EXISTS `community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community` (
  `article_count` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `end_at` date NOT NULL,
  `hits` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_deleted` bit(1) NOT NULL DEFAULT b'0',
  `max_participants` int NOT NULL,
  `start_at` date NOT NULL,
  `writer_id` int DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `notice` varchar(100) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkwuy5bkq1nauxy877cxfmh6il` (`category_id`),
  KEY `FK3bca947wxku2xpwxsln440lra` (`writer_id`),
  CONSTRAINT `FK3bca947wxku2xpwxsln440lra` FOREIGN KEY (`writer_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKkwuy5bkq1nauxy877cxfmh6il` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community`
--

LOCK TABLES `community` WRITE;
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` VALUES (1,5,'2024-05-07',111,1,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:15:57.464470',NULL,'2024-05-06 19:15:57.464470','춘배짱짱',NULL,'아아 안녕하세요'),(2,6,'2024-05-07',45,2,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:15:58.416860',NULL,'2024-05-06 19:15:58.416860','ourway',NULL,'내용도 바꾸기'),(3,4,'2024-05-07',3,3,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:15:59.277747',NULL,'2024-05-06 19:15:59.277747','705',NULL,'내용내용'),(4,3,'2024-05-07',12,4,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:11.479304',NULL,'2024-05-06 19:17:11.479304','readit화이팅',NULL,'readit짱'),(5,2,'2024-05-14',22,5,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:12.315900',NULL,'2024-05-06 19:17:12.315900','호랑이쫀드기',NULL,'아아 안녕하세요'),(1,1,'2024-05-14',31,6,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:13.192103',NULL,'2024-05-06 19:17:13.192103','매머드커피',NULL,'아아 안녕하세요'),(2,6,'2024-05-14',43,7,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:14.083591',NULL,'2024-05-06 19:17:14.083591','싸피',NULL,'아아 안녕하세요'),(3,6,'2024-05-14',2,8,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:14.998644',NULL,'2024-05-06 19:17:14.998644','아이스아메리카노',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,9,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,10,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,11,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,12,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,13,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,14,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,15,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,16,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,17,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,18,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,19,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,20,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,21,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,22,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,23,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,24,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요'),(4,6,'2024-05-14',1,25,_binary '\0',3,'2024-05-01',1,'2024-05-06 19:17:15.883923',NULL,'2024-05-06 19:17:15.883923','ㅎ',NULL,'아아 안녕하세요');
/*!40000 ALTER TABLE `community` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:24:08
